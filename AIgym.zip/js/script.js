/* ハンバーガメニュー
	--------------------------------------------------------- */
$(function () {
  $(document).ready(function () {
    $(".spmenu").on("click", function () {
      $(this).toggleClass("active");
      $("#spnav").toggleClass("active");
    });

    $("#spnav a").on("click", function () {
      $("#spnav").toggleClass("active");
      $(".spmenu").toggleClass("active");
    });
  });
});

/* FV Floating Banner
	--------------------------------------------------------- */
const fvFloat = document.getElementById("fv-float");
const FV_SCROLL_THRESHOLD = 100; // px スクロールでバナー表示

if (fvFloat) {
  window.addEventListener(
    "scroll",
    () => {
      if (window.scrollY > FV_SCROLL_THRESHOLD) {
        fvFloat.classList.add("is-visible");
      } else {
        fvFloat.classList.remove("is-visible");
      }
    },
    { passive: true },
  );
}

/* MV Swiper
	--------------------------------------------------------- */
const swiper_mv = new Swiper(".mv-swiper", {
  loop: true,
  pagination: {
    el: ".mv-swiper-pagination",
    clickable: true,
  },
  slidesPerView: 1,
  speed: 1000,
  autoplay: {
    delay: 5000,
    disableOnInteraction: false,
  },
});
